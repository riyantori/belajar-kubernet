# Diagram Belajar Kubernetes

Semua diagram dibuat menggunakan PlantUML.

Anda bisa me-render diagram nya di link :

http://www.plantuml.com/plantuml/uml/